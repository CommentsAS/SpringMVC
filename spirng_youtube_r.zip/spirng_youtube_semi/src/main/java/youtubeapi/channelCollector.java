package youtubeapi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.JSONException;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import lab.spring.youtube.model.ChannelVO;


public class channelCollector {
 public static String jsonReadAll(Reader reader) throws IOException {

    StringBuilder sb = new StringBuilder();
    int cp;
    while ((cp = reader.read()) != -1) {
       sb.append((char) cp);
    }
    return sb.toString();

 }

 public static String readJsonFromUrl(String url) throws IOException, JSONException {

    InputStream is = new URL(url).openStream();
    try {
    	BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
    	String jsonText = jsonReadAll(rd);
       
    	return jsonText;
       
    } finally {
    	is.close();
    }

 }
 
 
 @SuppressWarnings("null")
public ArrayList<String> getchannel(String cid) throws JSONException, IOException, ParseException{	 
	 String url = "https://www.googleapis.com/youtube/v3/channels?part=statistics";
	 String key = "AIzaSyB285xd8NfhXf0_vx0PXMTFqcD3oAiKS10";
	 String getURL = url + "&id=" + cid + "&key=" + key;
	 String json = readJsonFromUrl(getURL);
	 ArrayList<String> vo = new ArrayList<String>();
     
	 JSONParser jsonParser = new JSONParser();
       
	 //JSON데이터를 넣어 JSON Object 로 만들어 준다.
       JSONObject jsonObject = (JSONObject) jsonParser.parse(json);
       
       //books의 배열을 추출
       JSONArray bookInfoArray = (JSONArray) jsonObject.get("items");
       for(int i=0; i<bookInfoArray.size(); i++){
           //배열 안에 있는것도 JSON형식 이기 때문에 JSON Object 로 추출
    	   JSONObject bookObject1 = (JSONObject) bookInfoArray.get(i);
           bookObject1 = (JSONObject) bookObject1.get("statistics");
           vo.add(bookObject1.get("viewCount").toString());
           vo.add(bookObject1.get("subscriberCount").toString());
           vo.add(bookObject1.get("videoCount").toString());
           JSONObject bookObject2 = (JSONObject) bookInfoArray.get(i);
           vo.add(bookObject2.get("id").toString());
       }
       
       return vo;
 }
 
 
 
 
}