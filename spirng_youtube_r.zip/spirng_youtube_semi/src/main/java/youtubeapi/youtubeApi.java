package youtubeapi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import lab.spring.youtube.model.VideoVO;


public class youtubeApi {
	String key = "AIzaSyDJNjJqPS8p9LvDs9EMdMsBtMpp2mnzIE4";
	
 public String jsonReadAll(Reader reader) throws IOException {

    StringBuilder sb = new StringBuilder();
    int cp;
    while ((cp = reader.read()) != -1) {
       sb.append((char) cp);
    }
    return sb.toString();

 }

 public String readJsonFromUrl(String url) throws IOException, JSONException {

    InputStream is = new URL(url).openStream();
    try {
    	BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
    	String jsonText = jsonReadAll(rd);
       
    	return jsonText;
       
    } finally {
    	is.close();
    }

 }
 
 public void getcomment(String videoId) throws JSONException, IOException, ParseException{
	 System.out.println("댓글 collect 시작");
	String url="https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&maxResults=100&order=relevance";
	//String videoId = "lHtbq24lK5Y";
	String getURL = url+"&videoId="+videoId+"&key="+key;
	ArrayList<String> comments = new ArrayList<String>();
	
	String json = readJsonFromUrl(getURL);
	JSONParser jsonParser = new JSONParser();
	
	//JSON데이터를 넣어 JSON Object 로 만들어 준다.
	JSONObject jsonObject = (JSONObject) jsonParser.parse(json);
	    
	String token = (String) jsonObject.get("nextPageToken");
	//System.out.println(token);
	
	//처음엔 그냥 가져옴
	JSONArray bookInfoArray = (JSONArray) jsonObject.get("items");

	for(int i=0; i<bookInfoArray.size(); i++){
		//배열 안에 있는것도 JSON형식 이기 때문에 JSON Object 로 추출
		//json파일 안에 items > snippet > topLevelComment > snippet > ...
	    JSONObject bookObject = (JSONObject) bookInfoArray.get(i);
	    bookObject = (JSONObject) bookObject.get("snippet");
	    bookObject = (JSONObject) bookObject.get("topLevelComment");
	    bookObject = (JSONObject) bookObject.get("snippet");
	    //JSON name으로 추출
//	    System.out.println(++count +"번째 댓글 >");
//	    System.out.println("글쓴이 > "+bookObject.get("authorDisplayName"));
//	    System.out.println("댓  글 > "+bookObject.get("textOriginal"));
//	    System.out.println("좋아요 > "+bookObject.get("likeCount"));
//	    System.out.println("게시일 > "+bookObject.get("updatedAt"));
//	    System.out.println();
	    comments.add( bookObject.get("textOriginal").toString() );
	}

	// 페이지 토큰이 있으면 ?
	while(token!=null) {
		String nextURL = getURL+"&pageToken="+token;
	     
		json = readJsonFromUrl(nextURL);
		jsonParser = new JSONParser();
	  
		//JSON데이터를 넣어 JSON Object 로 만들어 준다.
		jsonObject = (JSONObject) jsonParser.parse(json);
		token = (String) jsonObject.get("nextPageToken");
	  
		bookInfoArray = (JSONArray) jsonObject.get("items");

		for(int i=0; i<bookInfoArray.size(); i++){

	         //배열 안에 있는것도 JSON형식 이기 때문에 JSON Object 로 추출
	        //json파일 안에 items > snippet > topLevelComment > snippet > ...
	         JSONObject bookObject = (JSONObject) bookInfoArray.get(i);
	         bookObject = (JSONObject) bookObject.get("snippet");
	         bookObject = (JSONObject) bookObject.get("topLevelComment");
	         bookObject = (JSONObject) bookObject.get("snippet");
	         //JSON name으로 추출
//	         System.out.println(++count +"번째 댓글 >");
//	         
//	         System.out.println("글쓴이 > "+bookObject.get("authorDisplayName"));
//	         System.out.println("댓  글 > "+bookObject.get("textOriginal"));
//	         System.out.println("좋아요 > "+bookObject.get("likeCount"));
//	         System.out.println("게시일 > "+bookObject.get("updatedAt"));
//	         System.out.println();
	         comments.add( bookObject.get("textOriginal").toString() );

	     }
		if(token==null) break;
	    if(comments.size() >= 1500) break;
	 }
	 
	try {
		//txt로 저장 
        String fileName = "c:/Users/yrb12/Desktop/youtube_anal_project/commentdata/comment1.txt" ;
        BufferedWriter fw = new BufferedWriter(new FileWriter(fileName,false));
        // 파일안에 문자열 쓰기
        for(int i=0; i<comments.size(); i++){
        	fw.write(comments.get(i)+"\r\n");
		}
        // 객체 닫기
        fw.flush();	
        fw.close();
        System.out.println("댓글수집완료");
	 } catch (Exception e) {
		e.printStackTrace();
	 }
     
 }//end get comment
 	
	public HashMap<String, String> getDesc_Pub(String id) throws JSONException, IOException, ParseException, java.text.ParseException{
		
		String url="https://www.googleapis.com/youtube/v3/channels?part=snippet";
		//String id = "UCDhAiu2aYWUoUYM7TJkkRcA";
		String getURL = url+"&id="+id+"&key="+key;
		
		
		ArrayList<VideoVO> videos = new ArrayList<VideoVO>();

		String json = readJsonFromUrl(getURL);
		JSONParser jsonParser = new JSONParser();

		//JSON데이터를 넣어 JSON Object 로 만들어 준다.
		JSONObject jsonObject = (JSONObject) jsonParser.parse(json);
		
		//items 에 결과 list 들어있음
		JSONArray ChannelInfoArray = (JSONArray) jsonObject.get("items");
		//items > snippet > description,publishedAt
		JSONObject jsonObject0 = (JSONObject) ChannelInfoArray.get(0);
		
		JSONObject snippet = (JSONObject) jsonObject0.get("snippet");
		String description = (String) snippet.get("description");
		String publishedAt = (String) snippet.get("publishedAt");
		
		//채널 운영일수 개산
		Date olddate = new SimpleDateFormat("yyyy-MM-dd").parse(publishedAt.substring(0, 10));
		Date time = new Date();
		publishedAt = Long.toString((time.getTime()-olddate.getTime())/ (24 * 60 * 60 * 1000));
		
		HashMap<String , String> map = new HashMap<String , String>();
		map.put("description", description);
		map.put("publishedAt", publishedAt);
		
		return map;

		

	}//end get comment
	
	public int getVideoCnt(String channelId) throws JSONException, IOException, ParseException{

		String url="https://www.googleapis.com/youtube/v3/search?part=snippet&order=date&maxResults=5&type=video";
		//String channelId = "UCDhAiu2aYWUoUYM7TJkkRcA";
		String getURL = url+"&channelId="+channelId+"&key="+key;
		ArrayList<VideoVO> videos = new ArrayList<VideoVO>();

		String json = readJsonFromUrl(getURL);
		JSONParser jsonParser = new JSONParser();

		//JSON데이터를 넣어 JSON Object 로 만들어 준다.
		JSONObject jsonObject = (JSONObject) jsonParser.parse(json);
		
		//items 에 결과 list 들어있음
		jsonObject = (JSONObject) jsonObject.get("pageInfo");
		int totalCnt = Integer.parseInt(jsonObject.get("totalResults").toString());
		

		return totalCnt;

		

	}//end get getVideCnt
	
	
	
	public ArrayList<VideoVO> getvideolist(String channelId) throws JSONException, IOException, ParseException{

		String url="https://www.googleapis.com/youtube/v3/search?part=snippet&order=date&maxResults=50&type=video";
		//String channelId = "UCDhAiu2aYWUoUYM7TJkkRcA";
		String getURL = url+"&channelId="+channelId+"&key="+key;
		ArrayList<VideoVO> videos = new ArrayList<VideoVO>();

		String json = readJsonFromUrl(getURL);
		JSONParser jsonParser = new JSONParser();
		
		//JSON데이터를 넣어 JSON Object 로 만들어 준다.
		JSONObject jsonObject = (JSONObject) jsonParser.parse(json);
		
		//items 에 결과 list 들어있음
		JSONArray videoListArray = (JSONArray) jsonObject.get("items");
		
		for(int i=0; i<videoListArray.size(); i++){
			//배열 안에 있는것도 JSON형식 이기 때문에 JSON Object 로 추출
			JSONObject videoObject = (JSONObject) videoListArray.get(i);
			//json파일 안에 items > id > videoId
			JSONObject videoIdObject = (JSONObject) videoObject.get("id");
			//JSON name으로 추출
//			System.out.println("videoid >"+videoIdObject.get("videoId"));
			String vid = videoIdObject.get("videoId").toString();
			//json파일 안에 items > snippet > ...
			JSONObject videoInfoObject = (JSONObject) videoObject.get("snippet");
//			System.out.println("publishedAt >"+videoInfoObject.get("publishedAt"));
//			System.out.println("title >"+videoInfoObject.get("title"));
			String title = videoInfoObject.get("title").toString();
			String vdate = videoInfoObject.get("publishedAt").toString();
			
			// items > snippet > thumbnail > default > ...
			videoInfoObject = (JSONObject) videoInfoObject.get("thumbnails");
			videoInfoObject = (JSONObject) videoInfoObject.get("default");
//			System.out.println("url >"+videoInfoObject.get("url"));
			String thumb = videoInfoObject.get("url").toString();
			
			VideoVO videoinfo = new VideoVO();
			videoinfo.setVid(vid);
			videoinfo.setTitle(title);
			videoinfo.setThumb(thumb);
			videoinfo.setVdate(vdate);
			videos.add(videoinfo);
		}
		
		if(videoListArray.size()==50) {
			String token = jsonObject.get("nextPageToken").toString();
			while(token!=null) {
				String nextURL = getURL+"&pageToken="+token;
			     
				json = readJsonFromUrl(nextURL);
				jsonParser = new JSONParser();
			  
				//JSON데이터를 넣어 JSON Object 로 만들어 준다.
				jsonObject = (JSONObject) jsonParser.parse(json);
				token = (String) jsonObject.get("nextPageToken");
				System.out.println(token);
				videoListArray = (JSONArray) jsonObject.get("items");
	
				for(int i=0; i<videoListArray.size(); i++){
	
					//배열 안에 있는것도 JSON형식 이기 때문에 JSON Object 로 추출
					JSONObject videoObject = (JSONObject) videoListArray.get(i);
					//json파일 안에 items > id > videoId
					JSONObject videoIdObject = (JSONObject) videoObject.get("id");
	
					//JSON name으로 추출
					String vid = videoIdObject.get("videoId").toString();
	//				System.out.println("videoid >"+videoIdObject.get("videoId"));
					//json파일 안에 items > snippet > ...
					JSONObject videoInfoObject = (JSONObject) videoObject.get("snippet");
	//				System.out.println("publishedAt >"+videoInfoObject.get("publishedAt"));
	//				System.out.println("title >"+videoInfoObject.get("title"));
					String title = videoInfoObject.get("title").toString();
					String vdate = videoInfoObject.get("publishedAt").toString();
					
					// items > snippet > thumbnail > default > ...
					videoInfoObject = (JSONObject) videoInfoObject.get("thumbnails");
					videoInfoObject = (JSONObject) videoInfoObject.get("default");
	//				System.out.println("url >"+videoInfoObject.get("url"));
					String thumb = videoInfoObject.get("url").toString();
					
					VideoVO videoinfo = new VideoVO();
					videoinfo.setVid(vid);
					videoinfo.setTitle(title);
					videoinfo.setThumb(thumb);
					videoinfo.setVdate(vdate);
					videos.add(videoinfo);
			        
			     }
				if(token==null) break; // 더이상 가져올 페이지가없으면
				if (videos.size() >= 100) break; // 영상 100개 까지만 가져오도록
			 }
			}
		
		return videos;

		

	}//end get videolist
	
}