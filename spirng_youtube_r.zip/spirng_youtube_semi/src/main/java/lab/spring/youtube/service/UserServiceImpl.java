package lab.spring.youtube.service;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lab.spring.youtube.dao.UserDAO;
import lab.spring.youtube.model.UserVO;

@Service("UserService")
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDAO dao;

	public int addUser(UserVO user) throws ParseException {
		return dao.addUser(user);
	}

	public UserVO login(String user_id, String pwd) {
		return dao.login(user_id, pwd);
	}
	
	public List<UserVO> getYoutuberList() {
		// TODO Auto-generated method stub
		return null;
	}
	public int savePoint(String user_id, int point) {
		return dao.savePoint(user_id, point);
	}
	
	public int checkId(String user_id) {
	    return dao.checkId(user_id);
	}

	public int checkCid(String cid) {
		return dao.checkCid(cid);
	}
}