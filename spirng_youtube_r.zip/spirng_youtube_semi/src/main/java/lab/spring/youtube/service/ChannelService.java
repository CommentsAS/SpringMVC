package lab.spring.youtube.service;

import java.util.List;

import lab.spring.youtube.model.ChannelVO;
import lab.spring.youtube.model.DateVO;
import lab.spring.youtube.model.NeuDicVO;

public interface ChannelService {
	public List<ChannelVO> subscriberTop();
	public List<ChannelVO> viewTop();
	public List<ChannelVO> videoTop();
	public ChannelVO channelInfo(String cid);
	public int currToPast(ChannelVO channel);
	public List<ChannelVO> collectCid();
	public int insertChannel(DateVO channel);
	public int currUpdate(ChannelVO channel);
	public int channelRank_all(String cid);
	public int channelRank_cate(ChannelVO channel);
	public int view_sub(ChannelVO channel);
	public int view_video(ChannelVO channel);
	public int sub_video(ChannelVO channel);
	public int count_cate(ChannelVO channel);
	public List<DateVO> pastTsubRank();
	public List<DateVO> pastTviewRank();
	public List<DateVO> pastTvideoRank();
	
	
	public List<String> getposdic();
	public List<String> getnegdic();
	   
	public int getdiccnt(String words);
	public int insertDic(NeuDicVO dicvo);
	public int updateDicPos(String words);
	public int updateDicNeg(String words);

}
