package lab.spring.youtube.model;

public class PN_DicVO {
   private String words;
   private boolean pn_type;
   
   public PN_DicVO() {
      super();
   }

   public PN_DicVO(String words, boolean pn_type) {
      super();
      this.words = words;
      this.pn_type = pn_type;
   }

   public String getWords() {
      return words;
   }

   public void setWords(String words) {
      this.words = words;
   }

   public boolean isPn_type() {
      return pn_type;
   }

   public void setPn_type(boolean pn_type) {
      this.pn_type = pn_type;
   }

   @Override
   public String toString() {
      return "PN_DicVO [words=" + words + ", pn_type=" + pn_type + "]";
   }
   
}