package lab.spring.youtube.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import lab.spring.youtube.model.ChannelVO;
import lab.spring.youtube.model.DateVO;
import lab.spring.youtube.model.NeuDicVO;
import lab.spring.youtube.model.PagingVO;
import lab.spring.youtube.model.UserVO;
import lab.spring.youtube.model.VideoVO;
import lab.spring.youtube.service.ChannelService;
import lab.spring.youtube.service.UserService;
import youtubeapi.channelCollector;
import youtubeapi.youtubeApi;


@Controller
public class ChannelController {

	@Autowired
	ChannelService service;
	@Autowired
	UserService service2;

	@RequestMapping(value="/main.do", method=RequestMethod.GET)
	public ModelAndView ranking() {	
		ModelAndView mav = new ModelAndView();
		
		// �����ڼ�, ��ȸ��, ���� ������ ���� �����ͼ� view������ �Ѱ��ֱ�
		List<ChannelVO> list1 = null;
		list1 = service.subscriberTop();
		mav.addObject("list1", list1);
	  
		List<ChannelVO> list2 = null;
		list2 = service.viewTop();
		mav.addObject("list2", list2);
	  
		List<ChannelVO> list3 = null;
		list3 = service.videoTop();
		mav.addObject("list3", list3);
		
		
		// date_info�� �����͸� �����ͼ� view������ �Ѱ��ֱ�
		int[] incre_sub = new int[100];
		int[] incre_view = new int[100];
		int[] incre_video = new int[100];
		List<DateVO> prank_sub = service.pastTsubRank();
		List<DateVO> prank_view = service.pastTviewRank();
		List<DateVO> prank_video = service.pastTvideoRank();
		  
		int i=0, j,k,l;
		while(i<100) {
			j=0;
			while(!(list1.get(i).getCid().equals(prank_sub.get(j).getCid()))) {
				j++;
			}
			incre_sub[i]=j-i;
			k=0;
			while(!(list2.get(i).getCid().equals(prank_view.get(k).getCid()))) {
				k++;
			}
			incre_view[i]=k-i;
			l=0;
			while(!(list3.get(i).getCid().equals(prank_video.get(l).getCid()))) {
				l++;
			}
			incre_video[i]=l-i;
			i++;
		}
		  
		mav.addObject("incre_sub",incre_sub);
		mav.addObject("incre_view",incre_view);
		mav.addObject("incre_video",incre_video);

		mav.setViewName("main2");
		return mav;
	}	

	
	
	@RequestMapping(value="/system.do", method=RequestMethod.GET)
	public ModelAndView system() {
		ModelAndView mav = new ModelAndView();

		System.out.println("������ ������ ����");

		mav.setViewName("system");
		return mav; 
	}
	
	
	// date_info ���� insert
	@RequestMapping(value="/date_insert.do", method=RequestMethod.POST)
	public ModelAndView dateInsert() throws IOException, JSONException, ParseException {
		ModelAndView mav = new ModelAndView();
		
		//		session.setAttribute("subscriber", list1);
		
		DateVO channel = new DateVO();
		List<ChannelVO> cid = null;
		int change = 0;
		
		// ä�� id�� ���� �ҷ��´�.
			cid = service.collectCid();
			
			System.out.println("id���� �Ϸ�");

			for(int j=0; 50*j<cid.size(); j++) {
				String id = "";
				
				for(int i=0; i<=49; i++) {
					// id 50���� ,�� �����ϴ� ����
					String id2 = "";
					if(i+50*j==cid.size()) { // ��ü �� ������ id�� �޸� �� ���̰� break
						id2 = cid.get(i+50*j-1).getCid();
						id += id2;
						break;
					}
					id2 = cid.get(i+50*j).getCid();
					if(i==49) { // �� ��Ʈ �� 50��° id�� �޸� �� ���̱�
						id += id2; break;	
					} else {
						id += id2 + ",";
						}
				} // for�� (i) end
				
				
				// ���� ��¥�� ex)191023 ������ String���� ����
				SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
				String format_time = format.format(System.currentTimeMillis());
				
				long tview = 0;
				long tsubscribe = 0;
				long tvideo = 0;
				
				channelCollector a = new channelCollector();
				
				List<String> k = new ArrayList();
				
				// youtube api�� 50���� id�� �� ���� ���
				k = a.getchannel(id);
				
				if (k.size() != 200) { // 50���� id�� ���� 4���� ������ �� ���� �޾ƿ��� ������ size=200�� ����
					System.out.println(id); // 50�� ���� �� �´� ��� id ã�� ���� sys out 
					// �޾ƿ� �����͸� ������ DateVO ��ü�� ������ �� �־� DB�� Insert�ϱ�
					
					for(int c=0; c<=k.size()-4; c=c+4) {	
						tview = Long.parseLong(k.get(c));
						tsubscribe = Long.parseLong(k.get(c+1));
						tvideo = Long.parseLong(k.get(c+2));
						String id3 = null;
						id3 = k.get(c+3);
						
						// channel ��ü�� �ش� ������ ��Ƽ� MyBatis�� �Ķ���ͷ� �ѱ�
						channel.setCid(id3);
						channel.setUpdate_day(format_time);
						channel.setTview(tview);
						channel.setTsubscribe(tsubscribe);
						channel.setTvideo(tvideo);
						
						change = service.insertChannel(channel);
					} // for��(c) end
					
				} else {
					for(int c=0; c<=196; c=c+4) {
						tview = Long.parseLong(k.get(c));
						tsubscribe = Long.parseLong(k.get(c+1));
						tvideo = Long.parseLong(k.get(c+2));
						String id3 = null;
						id3 = k.get(c+3);

						channel.setCid(id3);
						channel.setUpdate_day(format_time);
						channel.setTview(tview);
						channel.setTsubscribe(tsubscribe);
						channel.setTvideo(tvideo);

						change = service.insertChannel(channel);
					} // for��(c) end
				}
				System.out.println("Insert �Ϸ�" + j);

			} // for�� (j) end

			mav.setViewName("system");
			return mav; 
	}
	
	
	// channel_info �ֽ� �����ͷ� ������Ʈ
	@RequestMapping(value="/ch_update.do", method=RequestMethod.POST)
	public ModelAndView channelUpdate() throws IOException, JSONException, ParseException {	
		ModelAndView mav = new ModelAndView();
		
		ChannelVO channel = new ChannelVO();
		List<ChannelVO> cid = null;
		int change = 0;
		
		// ä�� id�� ���� �ҷ��´�.
			cid = service.collectCid();
			
			System.out.println("id���� �Ϸ�");
		
			for(int j=0; 50*j<cid.size(); j++) {
				String id = "";
				
				for(int i=0; i<=49; i++) {
					// id 50���� ,�� �����ϴ� ����
					String id2 = "";
					if(i+50*j==cid.size()) { // ��ü �� ������ id�� �޸� �� ���̰� break
						id2 = cid.get(i+50*j-1).getCid();
						id += id2;
						break;
					}
					id2 = cid.get(i+50*j).getCid();
					if(i==49) { // �� ��Ʈ �� 50��° id�� �޸� �� ���̱�
						id += id2; break;	
					} else {
						id += id2 + ",";
						}
				} // for�� (i) end
				
				
				long tview = 0;
				long tsubscribe = 0;
				long tvideo = 0;
				
				channelCollector a = new channelCollector();
				
				List<String> k = new ArrayList();
				
				// youtube api�� 50���� id�� �� ���� ���
				k = a.getchannel(id);
				
				if (k.size() != 200) { // 50���� id�� ���� 4���� ������ �� ���� �޾ƿ��� ������ size=200�� ����
					// �޾ƿ� �����͸� ������ DateVO ��ü�� ������ �� �־� DB�� Insert�ϱ�
					
					for(int c=0; c<=k.size()-4; c=c+4) {	
						tview = Long.parseLong(k.get(c));
						tsubscribe = Long.parseLong(k.get(c+1));
						tvideo = Long.parseLong(k.get(c+2));
						String id3 = null;
						id3 = k.get(c+3);
						
						if (id.contains(id3)) {
							id = id.replace(id3, "");
						}
						
						// channel ��ü�� �ش� ������ ��Ƽ� MyBatis�� �Ķ���ͷ� �ѱ�
						channel.setCid(id3);
						channel.setTview(tview);
						channel.setTsubscribe(tsubscribe);
						channel.setTvideo(tvideo);
						
						change = service.currUpdate(channel);
					} // for��(c) end
					System.out.println(id);
					
				} else {
					for(int c=0; c<=196; c=c+4) {
						tview = Long.parseLong(k.get(c));
						tsubscribe = Long.parseLong(k.get(c+1));
						tvideo = Long.parseLong(k.get(c+2));
						String id3 = null;
						id3 = k.get(c+3);

						channel.setCid(id3);
						channel.setTview(tview);
						channel.setTsubscribe(tsubscribe);
						channel.setTvideo(tvideo);

						change = service.currUpdate(channel);
					} // for��(c) end
				}
				System.out.println("Update �Ϸ�" + j);

			} // for�� (j) end

		mav.setViewName("system");
		return mav; 
	}	
	
	

	/////////////////////////////////////////////////////////////////////
	
	// �λ���Ʈ
	@RequestMapping(value="/in_channel.do", method=RequestMethod.GET)
	public ModelAndView insight_channel(HttpServletRequest request, HttpServletResponse response) throws JSONException, IOException, ParseException, java.text.ParseException {
		
		HttpSession session = request.getSession();	
		
		UserVO user = (UserVO) session.getAttribute("vo");
	      //System.out.println(user.getCid());
	     
			ModelAndView mav = new ModelAndView();
	      
	        if(user!=null) {
	           //�α��� �������� cid �̾ƿ�
	           ChannelVO channelInfo = null;
	           String cid = user.getCid();
	           channelInfo = service.channelInfo(cid);

	         //��ŷ ����
	           int rank_all = service.channelRank_all(cid);
	           int rank_cate = service.channelRank_cate(channelInfo);
	           
	           int view_sub = service.view_sub(channelInfo);
	           int view_video = service.view_video(channelInfo);
	           int sub_video = service.sub_video(channelInfo);
	           int count_cate = service.count_cate(channelInfo);

	           
	           //ä�� description, published date
	           youtubeApi a = new youtubeApi();
	           HashMap<String , String> map = a.getDesc_Pub(cid);
	           
	           
	           ///////////////
	           mav.addObject("channelInfo", channelInfo);
	           mav.addObject("rank_all", rank_all);
	           mav.addObject("rank_cate", rank_cate);
	           mav.addObject("view_sub", view_sub);
	           mav.addObject("view_video", view_video);
	           mav.addObject("sub_video", sub_video);
	           mav.addObject("count_cate", count_cate);
	           
	           mav.addObject("desc", map.get("description"));
	           mav.addObject("pubat", map.get("publishedAt"));
	           mav.setViewName("insight_channel");
	          
	      } else {
	         //��α��� ����
	    	  response.setContentType("text/html; charset=UTF-8");
	    	  PrintWriter out = response.getWriter();
	    	  out.println("<script> alert('�α��� �� �̿��� �� �ֽ��ϴ�.'); </script>");
	    	  out.flush();
	    	  mav.setViewName("login");
	      }
	        
	      return mav;
	}
	
	
	 //�λ���Ʈ(����&���)
	   @RequestMapping(value="/in_comment.do", method=RequestMethod.GET)
	   public ModelAndView insight_comment(HttpServletRequest request, HttpServletResponse response) throws JSONException, IOException, ParseException, java.text.ParseException {
	      HttpSession session = request.getSession();
	     
	        UserVO user = (UserVO) session.getAttribute("vo");
	      //System.out.println(user.getCid());
	        ModelAndView mav = new ModelAndView();
	      
	        if(user!=null) {
	           //�α��� �������� cid �̾ƿ�
	           ChannelVO channelInfo = null;
	           String cid = user.getCid();
	           channelInfo = service.channelInfo(cid);

	           //��ŷ ����
	           int rank_all = service.channelRank_all(cid);
	           int rank_cate = service.channelRank_cate(channelInfo);
	           
	           //ä�� description, published date
	           youtubeApi a = new youtubeApi();
	           HashMap<String , String> map = a.getDesc_Pub(cid);
	           
	           
	           ///////////////
	           mav.addObject("channelInfo", channelInfo);
	           mav.addObject("rank_all", rank_all);
	           mav.addObject("rank_cate", rank_cate);
	           mav.addObject("desc", map.get("description"));
	           mav.addObject("pubat", map.get("publishedAt"));
	          
	           mav.setViewName("insight_comment");
	          
	      } else {
	         //��α��� ����
	    	  response.setContentType("text/html; charset=UTF-8");
	    	  PrintWriter out = response.getWriter();
	    	  out.println("<script> alert('�α��� �� �̿��� �� �ֽ��ϴ�.'); </script>");
	    	  out.flush();
	    	  mav.setViewName("login");
	      }
	        
	      return mav;
	}
    
	   
	 //�λ���Ʈ�� ��ۺм�
	   @RequestMapping(value="/commentcount.do", method=RequestMethod.POST)
	   public ModelAndView commentcount(@RequestParam(value="vid", required=false) String vid,
	                                HttpSession session) throws JSONException, IOException, ParseException {
	      System.out.println("controller :" +vid);
	      ModelAndView mav = new ModelAndView();
	         
	      //��� �������� 
	      youtubeApi a = new youtubeApi();
	      a.getcomment(vid);
	      mav.addObject("vid", vid);
	       
	      //db ����� ���� ��������
	      List<String> negative_dic = service.getnegdic();
	      List<String> positive_dic = service.getposdic();
	      mav.addObject("negative_dic", negative_dic);
	      mav.addObject("positive_dic", positive_dic);
	          
	      System.out.println("mav ����");
	      mav.setViewName("commentcount");
	      return mav; 
	   } // commentCount end


        

		//�λ���Ʈ page ���� videolist
		@RequestMapping(value="/boardList.do", method=RequestMethod.GET)
		public String boardList(PagingVO vo, Model model
				, @RequestParam(value="nowPage", required=false)String nowPage
				, @RequestParam(value="cntPerPage", required=false)String cntPerPage
				, HttpSession session) throws JSONException, IOException, ParseException {
			
			System.out.println("boadrlist.do");
			
			if (nowPage == null && cntPerPage == null) {
				nowPage = "1";
				cntPerPage = "10";
				
				youtubeApi a = new youtubeApi();
				UserVO user = (UserVO) session.getAttribute("vo");
				String cid = user.getCid();
				int videocnt = a.getVideoCnt(cid);
				System.out.println(videocnt);
				
				ArrayList<VideoVO> videolist =  a.getvideolist(cid);
				session.setAttribute("videocnt", videocnt>100? 100 : videocnt);
				session.setAttribute("videolist", videolist);
			} else if (nowPage == null) {
				nowPage = "1";
			} else if (cntPerPage == null) { 
				cntPerPage = "10";
			}
			ArrayList<VideoVO> returnlist =  (ArrayList<VideoVO>) session.getAttribute("videolist");
			
			vo = new PagingVO((Integer)session.getAttribute("videocnt"), Integer.parseInt(nowPage), Integer.parseInt(cntPerPage));
//			System.out.println("vo.getStart()-1:"+ vo.getStart() + "vo.getEnd()-1:"+ vo.getEnd());
//			System.out.println("Integer.parseInt(nowPage)"+Integer.parseInt(nowPage));
//			System.out.println("vo.getLastPage()"+vo.getLastPage());
			model.addAttribute("paging", vo);
			
			
			if(Integer.parseInt(nowPage)==vo.getLastPage()) { //������������ ��û�ϸ�
				model.addAttribute("viewAll", returnlist.subList(vo.getStart()-1, (Integer)session.getAttribute("videocnt")));
			}else {
				model.addAttribute("viewAll", returnlist.subList(vo.getStart()-1, vo.getEnd()));
			}
			
			return "boardPaging";
		}//end boardList
	   
		
//		//���� �� 12�ÿ� ä�� ������ �ڵ� ������Ʈ �Ǵ� ���� ����
//		@Scheduled(cron="0/10 * * * * ?")
//		public void updateChannelInfo() {
//			System.out.println("�׽�Ʈ�Դϴ�.");
//			
//		}
		
		 //�λ���Ʈ-��� ������� db ����
		@RequestMapping(value="/adddic.do", method=RequestMethod.POST)
	      @ResponseBody
	      public void adddic(@RequestParam(value="items[]") List<String> params,
	                           @RequestParam(value="score[]") List<String> score,
	                           HttpServletRequest request){
	         System.out.println("controller adddic Ž");
	         Map<String,String> resultMap = new HashMap<String, String>();
	         //To save point!!!
	         HttpSession session = request.getSession();	
	 		 UserVO user=(UserVO) session.getAttribute("vo");
	 		 String user_id=user.getUser_id();
	         int point=0;
	         for(int i=0; i<params.size();i++) {
	            if(score.get(i).equals("1")) {
	               int cnt = service.getdiccnt(params.get(i));
	               if(cnt==1) { //�̹� ��ϵǾ� ������
	                  service.updateDicPos(params.get(i));
	               }else if(cnt==0) { //��ϵ� �ܾ �ƴϸ�
	                  NeuDicVO dicvo= new NeuDicVO(params.get(i),1,0);
	                  service.insertDic(dicvo);
	               }
	               point=point+10;
	            }else if(score.get(i).equals("-1")) {
	               //
	               int cnt = service.getdiccnt(params.get(i));
	               if(cnt==1) { //�̹� ��ϵǾ� ������
	                  service.updateDicNeg(params.get(i));
	               }else if(cnt==0) { //��ϵ� �ܾ �ƴϸ�
	                  NeuDicVO dicvo= new NeuDicVO(params.get(i),0,-1);
	                  service.insertDic(dicvo);
	               }
	               point=point+10;
	            }
	            //resultMap.put(params.get(i), score.get(i));
	         }
	         System.out.println(user_id);
	         System.out.println(point);
	         service2.savePoint(user_id, point);
	         
//	         for( String key : resultMap.keySet() ){
//	            System.out.println( "key : " + key + ", value : " + resultMap.get(key) ); 
//	         }

	      } // adddic end	
	      
}



