package lab.spring.youtube.service;

import java.text.ParseException;
import java.util.List;

import lab.spring.youtube.model.UserVO;

public interface UserService {
	public List<UserVO> getYoutuberList();
	public int addUser(UserVO user) throws ParseException;
	public UserVO login(String user_id, String pwd);
	public int savePoint(String user_id, int point);
	public int checkId(String user_id);
	public int checkCid(String cid);
}