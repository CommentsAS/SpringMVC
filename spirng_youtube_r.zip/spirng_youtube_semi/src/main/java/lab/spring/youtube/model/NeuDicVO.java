package lab.spring.youtube.model;

public class NeuDicVO {
   private String words;
   private int pos;
   private int neg;
   public NeuDicVO() {
      super();
   }
   public NeuDicVO(String words, int pos, int neg) {
      super();
      this.words = words;
      this.pos = pos;
      this.neg = neg;
   }
   public String getWords() {
      return words;
   }
   public void setWords(String words) {
      this.words = words;
   }
   public int getPos() {
      return pos;
   }
   public void setPos(int pos) {
      this.pos = pos;
   }
   public int getNeg() {
      return neg;
   }
   public void setNeg(int neg) {
      this.neg = neg;
   }
   @Override
   public String toString() {
      return "NeuDicVO [words=" + words + ", pos=" + pos + ", neg=" + neg + "]";
   }

}