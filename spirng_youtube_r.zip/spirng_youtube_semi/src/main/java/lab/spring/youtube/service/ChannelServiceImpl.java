package lab.spring.youtube.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lab.spring.youtube.dao.ChannelDAO;
import lab.spring.youtube.model.ChannelVO;
import lab.spring.youtube.model.DateVO;
import lab.spring.youtube.model.NeuDicVO;


@Service("ChannelService")
public class ChannelServiceImpl implements ChannelService {
	@Autowired
	private ChannelDAO dao;

	public List<ChannelVO> subscriberTop() {
		return dao.subscriberTop();
	}
	
	public List<ChannelVO> viewTop() {
		return dao.viewTop();
	}
	
	public List<ChannelVO> videoTop() {
		return dao.videoTop();
	}

	public ChannelVO channelInfo(String cid) {
		return dao.channelInfo(cid);
	}
	
	public int currToPast(ChannelVO channel) {
		return dao.currToPast(channel);
	}
	
	public List<ChannelVO> collectCid() {
		return dao.collectCid();
	}
	
	public int insertChannel(DateVO channel) {
		return dao.insertChannel(channel);
	}
	
	public int currUpdate(ChannelVO channel) {
		return dao.currUpdate(channel);
	}
	
	public int channelRank_all(String cid) {
		return dao.channelRank_all(cid);
	}
	
	public int channelRank_cate(ChannelVO channel) {
		return dao.channelRank_cate(channel);
	}
	
	public int view_sub(ChannelVO channel) {
		return dao.view_sub(channel);
	}
	
	public int view_video(ChannelVO channel) {
		return dao.view_video(channel);
	}
	
	public int sub_video(ChannelVO channel) {
		return dao.sub_video(channel);
	}
	
	public int count_cate(ChannelVO channel) {
		return dao.count_cate(channel);
	}
	
	public List<DateVO> pastTsubRank() {
		return dao.pastTsubRank();
	}

	public List<DateVO> pastTviewRank() {
		return dao.pastTviewRank();
	}

	public List<DateVO> pastTvideoRank() {
		return dao.pastTvideoRank();
	}

	public List<String> getposdic() {
		return dao.getposdic();
	}
		   
	public List<String> getnegdic() {
		return dao.getnegdic();
	}

		   
	public int getdiccnt(String words) {
		return dao.getdiccnt(words);
	}
	public int insertDic(NeuDicVO dicvo) {
		return dao.insertDic(dicvo);
	}
	public int updateDicPos(String words) {
		return dao.updateDicPos(words);
	}
	public int updateDicNeg(String words) {
		return dao.updateDicNeg(words);
	}	
}
