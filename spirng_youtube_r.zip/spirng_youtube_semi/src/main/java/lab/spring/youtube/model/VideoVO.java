package lab.spring.youtube.model;

public class VideoVO {
	private String cid;
	private String vid;
	private String vdate;
	private String title;
	private String description;
	private String thumb;
	private String tag;
	private long view;
	private long like;
	private long dislike;
	private long comment;
	private long favorite;
	
	public VideoVO() {
		super();
	}
	public VideoVO(String cid, String vid, String vdate, String title, String description, String thumb, String tag,
			long view, long like, long dislike, long comment, long favorite) {
		super();
		this.cid = cid;
		this.vid = vid;
		this.vdate = vdate;
		this.title = title;
		this.description = description;
		this.thumb = thumb;
		this.tag = tag;
		this.view = view;
		this.like = like;
		this.dislike = dislike;
		this.comment = comment;
		this.favorite = favorite;
	}
	
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getVid() {
		return vid;
	}
	public void setVid(String vid) {
		this.vid = vid;
	}
	public String getVdate() {
		return vdate;
	}
	public void setVdate(String vdate) {
		this.vdate = vdate;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getThumb() {
		return thumb;
	}
	public void setThumb(String thumb) {
		this.thumb = thumb;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public long getView() {
		return view;
	}
	public void setView(long view) {
		this.view = view;
	}
	public long getLike() {
		return like;
	}
	public void setLike(long like) {
		this.like = like;
	}
	public long getDislike() {
		return dislike;
	}
	public void setDislike(long dislike) {
		this.dislike = dislike;
	}
	public long getComment() {
		return comment;
	}
	public void setComment(long comment) {
		this.comment = comment;
	}
	public long getFavorite() {
		return favorite;
	}
	public void setFavorite(long favorite) {
		this.favorite = favorite;
	}
	
	@Override
	public String toString() {
		return "VideoVO [cid=" + cid + ", vid=" + vid + ", vdate=" + vdate + ", title=" + title + ", description="
				+ description + ", thumb=" + thumb + ", tag=" + tag + ", view=" + view + ", like=" + like + ", dislike="
				+ dislike + ", comment=" + comment + ", favorite=" + favorite + "]";
	}
	
}
