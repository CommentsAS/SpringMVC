package lab.spring.youtube.dao;

import java.util.HashMap;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import lab.spring.youtube.model.ChannelVO;
import lab.spring.youtube.model.DateVO;
import lab.spring.youtube.model.NeuDicVO;


@Repository
public class ChannelDAO {
	@Autowired
	private SqlSession sqlSession;

	public List<ChannelVO> subscriberTop() {
		return sqlSession.selectList("lab.mybatis.channel.ChannelMapper.subscriberTop");
	}
	
	public List<ChannelVO> viewTop() {
		return sqlSession.selectList("lab.mybatis.channel.ChannelMapper.viewTop");
	}
	
	public List<ChannelVO> videoTop() {
		return sqlSession.selectList("lab.mybatis.channel.ChannelMapper.videoTop");
	}
	
	public ChannelVO channelInfo(String cid) {
		return sqlSession.selectOne("lab.mybatis.channel.ChannelMapper.channelInfo",cid);
	}
	
	public int currToPast (ChannelVO channel) {
		return sqlSession.update("lab.mybatis.channel.ChannelMapper.currToPast", channel);
	}

	public List<ChannelVO> collectCid() {
		return sqlSession.selectList("lab.mybatis.channel.ChannelMapper.collectCid");
	}
	
	public int insertChannel(DateVO channel) {
		return sqlSession.insert("lab.mybatis.channel.ChannelMapper.insertChannel", channel);
	}
	
	public int currUpdate(ChannelVO channel) {
		return sqlSession.update("lab.mybatis.channel.ChannelMapper.currUpdate", channel);
	}
	
	public int channelRank_all(String cid) {
		return sqlSession.selectOne("lab.mybatis.channel.ChannelMapper.channelRank_all", cid);
	}
	
	public int channelRank_cate(ChannelVO channel) {
		return sqlSession.selectOne("lab.mybatis.channel.ChannelMapper.channelRank_cate", channel);
	}
	
	public int view_sub(ChannelVO channel) {
		return sqlSession.selectOne("lab.mybatis.channel.ChannelMapper.view_sub", channel);
	}
	
	public int view_video(ChannelVO channel) {
		return sqlSession.selectOne("lab.mybatis.channel.ChannelMapper.view_video", channel);
	}
	
	public int sub_video(ChannelVO channel) {
		return sqlSession.selectOne("lab.mybatis.channel.ChannelMapper.sub_video", channel);
	}
	
	public int count_cate(ChannelVO channel) {
		return sqlSession.selectOne("lab.mybatis.channel.ChannelMapper.count_cate", channel);
	}
	
	public List<DateVO> pastTsubRank() {
		return sqlSession.selectList("lab.mybatis.channel.ChannelMapper.pastTsubRank");
	}

	public List<DateVO> pastTviewRank() {
			return sqlSession.selectList("lab.mybatis.channel.ChannelMapper.pastTviewRank");
		}

	public List<DateVO> pastTvideoRank() {
			return sqlSession.selectList("lab.mybatis.channel.ChannelMapper.pastTvideoRank");
		}
	
	
// ��ü ����� ����	
	public List<String> getnegdic(){
	        return sqlSession.selectList("lab.mybatis.channel.ChannelMapper.getnegdic");
		}
		   
	public List<String> getposdic(){
	        return sqlSession.selectList("lab.mybatis.channel.ChannelMapper.getposdic");
	    }
		   		   
	public int getdiccnt(String words) {
			return sqlSession.selectOne("lab.mybatis.channel.ChannelMapper.getdiccnt", words);
		}
		   
	public int insertDic(NeuDicVO dicvo) {
			return sqlSession.insert("lab.mybatis.channel.ChannelMapper.insertDic", dicvo);
		}
		   
	public int updateDicPos(String words) {
			return sqlSession.update("lab.mybatis.channel.ChannelMapper.updateDicPos", words);
		}
		   
	public int updateDicNeg(String words) {
			return sqlSession.update("lab.mybatis.channel.ChannelMapper.updateDicNeg", words);
		}   	
	
}
