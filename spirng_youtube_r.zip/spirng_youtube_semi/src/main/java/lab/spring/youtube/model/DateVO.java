package lab.spring.youtube.model;

public class DateVO {
	private String cid;
	private int rnum;
	private String update_day;
	private long tview;
	private long tsubscribe;
	private long tvideo;

	
	public DateVO(String cid, int rnum, String update_day, long tview, long tsubscribe, long tvideo) {
		super();
		this.cid = cid;
		this.rnum = rnum;
		this.update_day = update_day;
		this.tview = tview;
		this.tsubscribe = tsubscribe;
		this.tvideo = tvideo;
	}
	public DateVO() {
		super();
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public int getRnum() {
		return rnum;
	}
	public void setRnum(int rnum) {
		this.rnum = rnum;
	}
	public String getUpdate_day() {
		return update_day;
	}
	public void setUpdate_day(String update_day) {
		this.update_day = update_day;
	}
	public long getTview() {
		return tview;
	}
	public void setTview(long tview) {
		this.tview = tview;
	}
	public long getTsubscribe() {
		return tsubscribe;
	}
	public void setTsubscribe(long tsubscribe) {
		this.tsubscribe = tsubscribe;
	}
	public long getTvideo() {
		return tvideo;
	}
	public void setTvideo(long tvideo) {
		this.tvideo = tvideo;
	}
	@Override
	public String toString() {
		return "DateVO [cid=" + cid + ", rnum=" + rnum + ", update_day=" + update_day + ", tview=" + tview + ", tsubscribe=" + tsubscribe
				+ ", tvideo=" + tvideo + "]";
	}
	
	
	

}
