package lab.spring.youtube.model;

public class CommentVO {
	private String cid;
	private String vid;
	private String udate;
	private String words;
	private long lcount;
	
	public CommentVO() {
		super();
	}
	public CommentVO(String cid, String vid, String udate, String words, int lcount) {
		super();
		this.cid = cid;
		this.vid = vid;
		this.udate = udate;
		this.words = words;
		this.lcount = lcount;
	}
	
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getVid() {
		return vid;
	}
	public void setVid(String vid) {
		this.vid = vid;
	}
	public String getUdate() {
		return udate;
	}
	public void setUdate(String udate) {
		this.udate = udate;
	}
	public String getWords() {
		return words;
	}
	public void setWords(String words) {
		this.words = words;
	}
	public long getLcount() {
		return lcount;
	}
	public void setLcount(int lcount) {
		this.lcount = lcount;
	}
	
	@Override
	public String toString() {
		return "CommentVO [cid=" + cid + ", vid=" + vid + ", udate=" + udate + ", words=" + words + ", lcount=" + lcount
				+ "]";
	}
		
}
