package lab.spring.youtube.model;

public class ChannelVO {
	private String cid;
	private String cname;
	private String thumb;
	private String cate;
	private String cate_num;
	private long tview;
	private long tsubscribe;
	private long tvideo;
	
	public ChannelVO() {
		super();
	}
	public ChannelVO(String cid, String cname, String thumb, String cate, String cate_num, long tview, long tsubscribe, long tvideo) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.thumb = thumb;
		this.cate = cate;
		this.cate_num = cate_num;
		this.tview = tview;
		this.tsubscribe = tsubscribe;
		this.tvideo = tvideo;

	}
	
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getThumb() {
		return thumb;
	}
	public void setThumb(String thumb) {
		this.thumb = thumb;
	}
	public String getCate() {
		return cate;
	}
	public void setCate(String cate) {
		this.cate = cate;
	}
	public String getCate_num() {
		return cate_num;
	}
	public void setCate_num(String cate_num) {
		this.cate_num = cate_num;
	}
	public long getTview() {
		return tview;
	}
	public void setTview(long tview) {
		this.tview = tview;
	}
	public long getTsubscribe() {
		return tsubscribe;
	}
	public void setTsubscribe(long tsubscribe) {
		this.tsubscribe = tsubscribe;
	}
	public long getTvideo() {
		return tvideo;
	}
	public void setTvideo(long tvideo) {
		this.tvideo = tvideo;
	}

	
	@Override
	public String toString() {
		return "ChannelVO [cid=" + cid + ", cname=" + cname + ", thumb=" + thumb + ", cate=" + cate + ", cate_num=" + cate_num + ", tview=" + tview
				+ ", tsubscribe=" + tsubscribe + ", tvideo=" + tvideo + "]";
	}
		
}
