package Rserve;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.RList;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

public class rJava_Con {

    public RConnection r = null;
    public REXP x = null;
    public String retStr = "";

    public rJava_Con() throws RserveException {
        this.r = new RConnection();
    }
    
    @SuppressWarnings("unchecked")
	public static List sortByValue(final Map map) {
        List<String> list = new ArrayList<String>();
        list.addAll(map.keySet());

        Collections.sort(list,new Comparator() {
            public int compare(Object o1,Object o2) {
                Object v1 = map.get(o1);
                Object v2 = map.get(o2);
                return ((Comparable) v2).compareTo(v1);
            }
        });
        //Collections.reverse(list); // �ּ��� ��������
        return list;
    }
    
    public Map<String,Object> returnRClass() throws REXPMismatchException, REngineException{
    	

        String device = "jpeg";
        System.out.println("1-1");

        x = r.parseAndEval("try("+device+"('c:/Users/yrb12/Desktop/youtube_anal_project/test.jpg',quality=100))");
        r.parseAndEval("source('C:/Users/yrb12/Desktop/youtube_anal_project/commentdata/wordcount.R')"); 
        
        System.out.println("1-2");

        r.parseAndEval("graphics.off()");  
    
        System.out.println("1-3");
    
        x = r.parseAndEval("r=readBin('c:/Users/yrb12/Desktop/youtube_anal_project/test.jpg','raw',1024*1024); unlink('c:/Users/yrb12/Desktop/youtube_anal_project/test.jpg'); r");
      
        System.out.println("1-4");

        RList top50list =r.parseAndEval("as.data.frame(wordcount_top)").asList();
        String[] word = top50list.at("data_unlist").asStrings();
        int[] count = top50list.at("Freq").asIntegers();
        
        Map<String, Integer> top50word = new HashMap<String, Integer>();	
        
        for(int i=0;i<word.length;i++) {
        	if(word[i].equals("")||word[i].equals(" ")) continue;
        	top50word.put(word[i], count[i]);
        }
        
        
        
        //////////////
//        Iterator it = sortByValue(top50word).iterator();
//        while(it.hasNext()) {
//            String temp = (String) it.next();
//            System.out.println(temp + " = " + top50word.get(temp));
//        }
        
        ///////////
        
        Map<String, Object> rrrr = new HashMap<String, Object>();
        
        rrrr.put("top50word", top50word);
        rrrr.put("image", x.asBytes());
        
        
        
        return rrrr;
      
     }
    
    
    
    public byte[] comment() throws REXPMismatchException, REngineException{
        String device = "png";
        x = r.parseAndEval("try("+device+"(file='c:/Users/yrb12/Desktop/youtube_anal_project/test.png', width=400, height=400, res=72))");
        System.out.println("2-1");
       
        r.parseAndEval("source('C:/Users/yrb12/Desktop/youtube_anal_project/commentdata/sentiment.R')");
        System.out.println("2-2");

        
        r.parseAndEval("graphics.off()");
        System.out.println("2-3");

        x = r.parseAndEval("r=readBin('c:/Users/yrb12/Desktop/youtube_anal_project/test.png','raw',1024*1024); unlink('c:/Users/yrb12/Desktop/youtube_anal_project/test.png'); r");
        System.out.println("2-4");
       
      return x.asBytes();
    }
    
}