package Rserve;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

public class Plot_Con {

    public RConnection r = null;
    public REXP x = null;
    public String retStr = "";
    String ucid="";

    public Plot_Con(String ucid) throws RserveException {
        this.r = new RConnection();
        this.ucid=ucid;
    }


    public void Rggplot() throws REngineException, REXPMismatchException {
    	r.parseAndEval("library(KoNLP)");
        r.parseAndEval("library(ggplot2)");
        r.parseAndEval("library(rJava)");
        r.parseAndEval("library(DBI)");
        r.parseAndEval("library(RJDBC)");
        r.parseAndEval("library(RColorBrewer)");
        r.parseAndEval("library(dplyr)");
        
        String style="plot.title=element_text(face=\"bold\", color=\"#666666\", hjust = 0.5, size=20),axis.title=element_text(face=\"bold\",size=15, color=\"gray\"),axis.text=element_text(size=12)";
        
        //1. ī�װ��� ������ ���� ��ġ ǥ���ϴ� plot
        //1-1) ���� ��ȯ�ϴ� ����������Լ�
        r.parseAndEval("convertNum<-function(num){\n" + 
              "ko_num<-function(x) {"+ 
              "if(is.na(x)){ new_num<-x; return(paste(new_num, 'NA', sep = '')); }\n"+
              "if(x<=9999){new_num<-x; return(paste(floor(new_num), '', sep = ''));}\n" + 
              "else if(x>9999&&x<9999999){new_num<-x / 1000; return(paste(round(new_num,2), 'K', sep = ''));}\n" + 
              "else if(9999999<=x){new_num = x / 1000000; return(paste(round(new_num,2), 'M', sep = ''));}}\n" + 
              "return(sapply(num, ko_num));}");
        //1-2) dbȣ��
        r.parseAndEval("drv_Oracle <- JDBC(driverClass=\"oracle.jdbc.OracleDriver\", classPath=\"C:/ojdbc6.jar\")");
        r.parseAndEval("con_Oracle <- dbConnect(drv_Oracle,\"jdbc:oracle:thin:@70.12.227.216:1521:orcl\",\"youtube2\",\"1234\")");
        
        //1-3) # SQL Query
        // data<= user�� ���� ī�װ��� ��� get
        r.parseAndEval("query_getChannelInfo <- \"SELECT * FROM channel_info WHERE cate_num=(SELECT category FROM user_info WHERE cid='"+ucid+"')\"");
        // user_data<= user channel ���� get
        r.parseAndEval("query_getuserChannelInfo <- \"SELECT * FROM channel_info where cid='"+ucid+"'\"");
        
        r.parseAndEval("chInfo<-dbGetQuery(con_Oracle, query_getChannelInfo)");
        r.parseAndEval("user_chInfo<-dbGetQuery(con_Oracle, query_getuserChannelInfo)");

        //1-4) user channel��/ �ƴ� ��(other) �׷츸��� �׷����� ǥ��
        r.parseAndEval("group<-chInfo$CNAME");
        r.parseAndEval("idx<-group %in% user_chInfo$CNAME");
        r.parseAndEval("group[idx]<-\"my channel\"");
        r.parseAndEval("group[!idx]<-\"others\"");
        
        //1-5) �� png ������ ���� �� �� ���� �׸��� ���� <<# path ���� �ʼ� >>
        String path; 
        path="\"c:/Users/yrb12/Desktop/youtube_anal_project/spirng_youtube_semi/src/main/webapp/resources/images/";
        
        // view/video
        r.eval("png(filename="+path+"vvd_plot.png\", width=500, height =350)");
        r.parseAndEval("print(ggplot(chInfo, aes(x=chInfo$TVIDEO, y=chInfo$TVIEW, col=group, size=group))+geom_point()+geom_text(label=chInfo$CNAME, hjust=-.1, check_overlap = T, col='#666666')+scale_color_manual(values=c('red','pink'))+scale_size_manual(values=c(5,5))+labs(x=\"VIDEO\", y=\"VIEW\")+theme("+style+",legend.title = element_blank())+scale_y_continuous(labels=convertNum)); dev.off()");
        // view/subscribe
        r.eval("png(filename="+path+"vs_plot.png\",  width=500, height =350)");
        r.parseAndEval("print(ggplot(chInfo, aes(x=chInfo$TSUBSCRIBE, y=chInfo$TVIEW, col=group, size=group))+geom_point()+geom_text(label=chInfo$CNAME, hjust=-.1, check_overlap = T, col='#666666')+scale_color_manual(values=c('red','pink'))+scale_size_manual(values=c(5,5))+labs(x=\"SUBSCRIBE\", y=\"VIEW\")+theme("+style+", legend.title = element_blank())+scale_x_continuous(labels= convertNum)+scale_y_continuous( labels= convertNum)); dev.off()");
        // subscribe/video
        r.eval("png(filename="+path+"svd_plot.png\",  width=500, height =350)");
        r.parseAndEval("print(ggplot(chInfo, aes(x=chInfo$TVIDEO, y=chInfo$TSUBSCRIBE, col=group, size=group))+geom_point()+geom_text(label=chInfo$CNAME, hjust=-.1, check_overlap = T, col='#666666')+scale_color_manual(values=c('red','pink'))+scale_size_manual(values=c(5,5))+labs(x=\"VIDEO\", y=\"SUBSCRIBE\")+theme("+style+", legend.title = element_blank())+scale_y_continuous(labels=convertNum)); dev.off()");


        //# 2. ī�װ��� �� �м� pie chart
        //2-1) # SQL Query [ category��, ������/��ȸ/���� �� �� ]
        r.parseAndEval("query_getCateTotal <- \"SELECT cate, sum(tsubscribe) catetsub, sum(tview) catetview, sum(tvideo) catetvideo from channel_info group by cate\"");
              
        //2-2) query����
        r.parseAndEval("Tcate_df <- dbGetQuery(con_Oracle, query_getCateTotal)");

        //2-3) sub
        //2-3.1) save the value of columns
        r.parseAndEval("cate<-Tcate_df$CATE");
        r.parseAndEval("tsub<-Tcate_df$CATETSUB");
        r.parseAndEval("subset_tsub<-subset(Tcate_df, select=c(1,2))");
              
        //2-3.2) calculate share(percentile) and insert into the data.frame
        r.parseAndEval("sub_df<-subset_tsub %>% mutate(share_tsub=tsub/sum(tsub)*100) %>% arrange(desc(tsub))");
        
        //2-3.3) combine 11~19st category => 1~10st category and others
              r.parseAndEval("x<-sum(sub_df[c(11:19),2])");
              r.parseAndEval("y<-sum(sub_df[c(11:19),3])");
              r.parseAndEval("sub_df<-rbind(sub_df,list(\"others\", x, y))");
              r.parseAndEval("sub_df<-sub_df[c(-11:-19),]");
              r.parseAndEval("group<-factor(sub_df$CATE, levels=as.character(sub_df$CATE))");
              
              //2-3.4) create pie chart // path������ 59�࿡��
              r.eval("png(filename="+path+"cateSub_chart.png\", width=500, height =350)");
              r.parseAndEval("print(ggplot(sub_df, aes(x=\"\",y=share_tsub,fill=group))"
              		+ "+geom_bar(width=1, color=\"white\", size=0.3, stat=\"identity\")+coord_polar(\"y\")"
              		+ "+geom_text(aes(label=paste0(round(share_tsub),\"%\")), position=position_stack(vjust = 0.5),size=5)"
              		+ "+theme_classic() + theme(axis.line = element_blank(),axis.text = element_blank(),axis.ticks = element_blank(),axis.title = element_blank(),legend.title = element_blank(),legend.text = element_text(size=15, color = \"#666666\"),plot.title = element_text(hjust = 0.5, color = \"#666666\", size=20))"
              		+ "+scale_fill_brewer(palette=\"Set3\"))"
              		+ "; dev.off()");
              
              //2-4) view
              //2-4.1) save the value of columns
              r.parseAndEval("cate<-Tcate_df$CATE");
              r.parseAndEval("tview<-Tcate_df$CATETVIEW");
              r.parseAndEval("subset_tview<-subset(Tcate_df, select=c(1,3))");
              
              //2-4.2) calculate share(percentile) and insert into the data.frame
              r.parseAndEval("view_df<-subset_tview %>% mutate(share_tview=tview/sum(tview)*100) %>% arrange(desc(tview))");
              
              //2-4.3) combine 11~19st category => 1~10st category and others
              r.parseAndEval("x<-sum(view_df[c(11:19),2])");
              r.parseAndEval("y<-sum(view_df[c(11:19),3])");
              r.parseAndEval("view_df<-rbind(view_df,list(\"others\", x, y))");
              r.parseAndEval("view_df<-view_df[c(-11:-19),]");
              r.parseAndEval("group<-factor(view_df$CATE, levels=as.character(view_df$CATE))");
              //2-4.4) create pie chart // path������ 59�࿡��
              r.eval("png(filename="+path+"cateView_chart.png\", width=500, height =350)");
              r.parseAndEval("print(ggplot(view_df, aes(x=\"\",y=share_tview,fill=group))"
              		+ "+geom_bar(width=1, color=\"white\", size=0.3, stat=\"identity\")+coord_polar(\"y\")"
              		+ "+geom_text(aes(label=paste0(round(share_tview),\"%\")), position=position_stack(vjust = 0.5),size=5)"
              		+ "+theme_classic() + theme(axis.line = element_blank(),axis.text = element_blank(),axis.ticks = element_blank(),axis.title = element_blank(),legend.title = element_blank(),legend.text = element_text(size=15, color = \"#666666\"),plot.title = element_text(hjust = 0.5, color = \"#666666\", size=20))"
              		+ "+scale_fill_brewer(palette=\"Set3\"))"
              		+ "; dev.off()");
            //2-5) video
              //2-5.1) save the value of columns
              r.parseAndEval("cate<-Tcate_df$CATE");
              r.parseAndEval("tvideo<-Tcate_df$CATETVIDEO");
              r.parseAndEval("subset_tvideo<-subset(Tcate_df, select=c(1,4))");
              
              //2-5.2) calculate share(percentile) and insert into the data.frame
              r.parseAndEval("video_df<-subset_tvideo %>% mutate(share_tvideo=tvideo/sum(tvideo)*100) %>% arrange(desc(tvideo))");
              
              //2-5.3) combine 11~19st category => 1~10st category and others
              r.parseAndEval("x<-sum(video_df[c(11:19),2])");
              r.parseAndEval("y<-sum(video_df[c(11:19),3])");
              r.parseAndEval("video_df<-rbind(video_df,list(\"others\", x, y))");
              r.parseAndEval("video_df<-video_df[c(-11:-19),]");
              r.parseAndEval("group<-factor(video_df$CATE, levels=as.character(video_df$CATE))");
              //2-5.4) create pie chart // path������ 59�࿡��
              r.eval("png(filename="+path+"cateVideo_chart.png\", width=500, height =350)");
              r.parseAndEval("print(ggplot(video_df, aes(x=\"\",y=share_tvideo,fill=group))"
              		+ "+geom_bar(width=1, color=\"white\", size=0.3, stat=\"identity\")+coord_polar(\"y\")"
              		+ "+geom_text(aes(label=paste0(round(share_tvideo),\"%\")), position=position_stack(vjust = 0.5),size=5)"
              		+ "+theme_classic() + theme(axis.line = element_blank(),axis.text = element_blank(),axis.ticks = element_blank(),axis.title = element_blank(),legend.title = element_blank(),legend.text = element_text(size=15, color = \"#666666\"),plot.title = element_text(hjust = 0.5, color = \"#666666\", size=20))"
              		+ "+scale_fill_brewer(palette=\"Set3\"))"
              		+ "; dev.off()");
              
           // # 3.personal trend line graph
              //3-1. send Query
              r.parseAndEval("query_myTrend <- \"SELECT * FROM date_info WHERE cid='"+ucid+"'\"");
              r.parseAndEval("myTrend_df <- dbGetQuery(con_Oracle, query_myTrend)");
              r.parseAndEval("myTrend_df$UPDATE_DAY<-substr(myTrend_df$UPDATE_DAY,3,6)");
              //3-2. create png and save the graph
              r.eval("png(filename="+path+"myViewTrend.png\", width=500, height =350)");
              r.parseAndEval("print(ggplot(myTrend_df, aes(x=myTrend_df$UPDATE_DAY, y=myTrend_df$TVIEW, group=myTrend_df$CID))+geom_line(size=2, col='pink')+geom_point(size=2, col='#D151B7')+labs(x=\"DAY\", y=\"VIEW\")+theme("+style+")+scale_y_continuous(labels=convertNum)); dev.off()"); 
              
              r.eval("png(filename="+path+"mySubTrend.png\", width=500, height =350)");
              r.parseAndEval("print(ggplot(myTrend_df, aes(x=myTrend_df$UPDATE_DAY, y=myTrend_df$TSUBSCRIBE, group=myTrend_df$CID))+geom_line(size=2, col='pink')+geom_point(size=2, col='#D151B7')+labs(x=\"DAY\", y=\"SUBSCRIBE\")+theme("+style+")+scale_y_continuous(labels=convertNum)); dev.off()");
              
              r.eval("png(filename="+path+"myVideoTrend.png\", width=500, height =350)");
              r.parseAndEval("print(ggplot(myTrend_df, aes(x=myTrend_df$UPDATE_DAY, y=myTrend_df$TVIDEO, group=myTrend_df$CID))+geom_line(size=2, col='pink')+geom_point(size=2, col='#D151B7')+labs(x=\"DAY\", y=\"VIDEO\")+theme("+style+")+scale_y_continuous(breaks=seq(min(myTrend_df$TVIDEO), max(myTrend_df$TVIDEO),1))); dev.off()");

    
    }
}