package example;

import java.text.SimpleDateFormat;

public class dateTest {

	public static void main(String[] args) {
//		SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
//		String format_time = format.format(System.currentTimeMillis());
//		System.out.println(format_time);
		

	}

}
