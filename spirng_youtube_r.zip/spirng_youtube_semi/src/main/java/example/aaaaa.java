package example;
//���� ��� 100�� ��������

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



public class aaaaa {
 public static String jsonReadAll(Reader reader) throws IOException {

    StringBuilder sb = new StringBuilder();
    int cp;
    while ((cp = reader.read()) != -1) {
       sb.append((char) cp);
    }
    return sb.toString();

 }

 public static String readJsonFromUrl(String url) throws IOException, JSONException {

    InputStream is = new URL(url).openStream();
    try {
       BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
       String jsonText = jsonReadAll(rd);
       
       return jsonText;
       
    } finally {
       is.close();
    }

 }
 
 public static void main(String[] args) throws JSONException, IOException, ParseException{

    
   String url="https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&maxResults=100&order=relevance";
    String videoId = "lHtbq24lK5Y";
    String key = "AIzaSyD5t4m9O3SmRDJWYfnMh2D9XGxUPasT5X0";
    String getURL = url+"&videoId="+videoId+"&key="+key;
    ArrayList<String> comments = new ArrayList<String>();
    
    String json = readJsonFromUrl(getURL);
    JSONParser jsonParser = new JSONParser();
    
    //JSON�����͸� �־� JSON Object �� ����� �ش�.
   JSONObject jsonObject = (JSONObject) jsonParser.parse(json);
        
   String token = (String) jsonObject.get("nextPageToken");
   //System.out.println(token);
  
   //ó���� �׳� ������
   JSONArray bookInfoArray = (JSONArray) jsonObject.get("items");

   int count=0;
   for(int i=0; i<bookInfoArray.size(); i++){
      //�迭 �ȿ� �ִ°͵� JSON���� �̱� ������ JSON Object �� ����
      //json���� �ȿ� items > snippet > topLevelComment > snippet > ...
       JSONObject bookObject = (JSONObject) bookInfoArray.get(i);
       bookObject = (JSONObject) bookObject.get("snippet");
       bookObject = (JSONObject) bookObject.get("topLevelComment");
       bookObject = (JSONObject) bookObject.get("snippet");
       //JSON name���� ����
       System.out.println(++count +"��° ��� >");
       System.out.println("�۾��� > "+bookObject.get("authorDisplayName"));
       System.out.println("��  �� > "+bookObject.get("textOriginal"));
       System.out.println("���ƿ� > "+bookObject.get("likeCount"));
       System.out.println("�Խ��� > "+bookObject.get("updatedAt"));
       System.out.println();
       comments.add( bookObject.get("textOriginal").toString() );
   }

   // ������ ��ū�� ������ ?
   while(token!=null) {
      String nextURL = getURL+"&pageToken="+token;
         
      json = readJsonFromUrl(nextURL);
      jsonParser = new JSONParser();
      
      //JSON�����͸� �־� JSON Object �� ����� �ش�.
      jsonObject = (JSONObject) jsonParser.parse(json);
      token = (String) jsonObject.get("nextPageToken");
      
      bookInfoArray = (JSONArray) jsonObject.get("items");

      for(int i=0; i<bookInfoArray.size(); i++){

             //�迭 �ȿ� �ִ°͵� JSON���� �̱� ������ JSON Object �� ����
            //json���� �ȿ� items > snippet > topLevelComment > snippet > ...
             JSONObject bookObject = (JSONObject) bookInfoArray.get(i);
             bookObject = (JSONObject) bookObject.get("snippet");
             bookObject = (JSONObject) bookObject.get("topLevelComment");
             bookObject = (JSONObject) bookObject.get("snippet");
             //JSON name���� ����
             System.out.println(++count +"��° ��� >");
             
             System.out.println("�۾��� > "+bookObject.get("authorDisplayName"));
             System.out.println("��  �� > "+bookObject.get("textOriginal"));
             System.out.println("���ƿ� > "+bookObject.get("likeCount"));
             System.out.println("�Խ��� > "+bookObject.get("updatedAt"));
             System.out.println();
             comments.add( bookObject.get("textOriginal").toString() );
             

         }
      if(token==null) break;
        
     } //while end
     
   try {
      // csv�� ����
//      String csvFileName = "c:/commentdata/comment1.csv";
//            
//      BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(csvFileName),"MS949"));
//      for(int i=0; i<comments.size(); i++){
//         writer.write(comments.get(i)+"\r\n");
//      }
//      writer.close();
      
      //txt�� ���� 
        String fileName = "c:/commentdata/comment1.txt" ;
        BufferedWriter fw = new BufferedWriter(new FileWriter(fileName, true));
        
        // ���Ͼȿ� ���ڿ� ����
        for(int i=0; i<comments.size(); i++){
           fw.write(comments.get(i)+"\r\n");
      }

        // ��ü �ݱ�
        fw.flush();   
        fw.close();


    } catch (Exception e) {
      e.printStackTrace();
   }
     
  
     
 }
 
}