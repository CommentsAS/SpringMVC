package example;
//���� ��� 100�� ��������

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



public class aaaaa2 {
 public static String jsonReadAll(Reader reader) throws IOException {

    StringBuilder sb = new StringBuilder();
    int cp;
    while ((cp = reader.read()) != -1) {
       sb.append((char) cp);
    }
    return sb.toString();

 }

 public static String readJsonFromUrl(String url) throws IOException, JSONException {

    InputStream is = new URL(url).openStream();
    try {
       BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
       String jsonText = jsonReadAll(rd);
       
       return jsonText;
       
    } finally {
       is.close();
    }

 }
 
 public static void main(String[] args) throws JSONException, IOException, ParseException{
	 String url = "https://www.googleapis.com/youtube/v3/channels?part=statistics";
	 String key = "AIzaSyB285xd8NfhXf0_vx0PXMTFqcD3oAiKS10";
	 String id = "UCvYNIMr1bUDABwHw3w3biew,"
	 		+ "UCZmxXPdl_KgmTdcLr_wAFoA,"
	 		+ "UCZo3yJ0wjksu7AZAjPMCgbA,"
	 		+ "UCZpoKUPSHL0Uk6yrj9EK-qA,"
	 		+ "UCZr3cu75jx6Sz-6KRQ50ySA,"
	 		+ "UCZr7BcQMia_aVJtHJk63lGg,"
	 		+ "UCZsWyGhLI37N-gOA_wT5o1Q,"
	 		+ "UCaa_Naj45pKHfX3sjjB7-BA,"
	 		+ "UCK45lxAV_92LqR2DcQCP8Qg,"
	 		+ "UCK4BHTqT-UNp2ncbD_hzF5g,"
	 		+ "UCK56MrtwI9LXHW0pww5wXqA,"
	 		+ "UCK5hD8LUbX7eCmgou1VC77A,"
	 		+ "UCK640DRZhYIxtaezqP56hPA,"
	 		+ "UCK8GEypZkYYDD-upBiT1d3Q,"
	 		+ "UCKA_6r3CWC76x_EaFO6jsPA,"
	 		+ "UCKCLjE6UrEqUOIKp9hnG9Ew,"
	 		+ "UCKDBdp6uG15ZhFA501Ftmew,"
	 		+ "UCKDCgsG8qjbF9_Ps6DSeBog,"
	 		+ "UCKDryfi71TjzKFkr9J9wzew,"
	 		+ "UCKFakQUa9S6TXO15xjYA1Eg,"
	 		+ "UCKFccyIQzgDYjXup8Is0mxg,"
	 		+ "UCKG1FQU_Iz5vYvO7_w10_gg,"
	 		+ "UCKG_mmhxqmAKlq-TX03_55w,"
	 		+ "UCKIzcYiCE_UGd_8erpNOC4g,"
	 		+ "UCKJC17Vw1IFpYZb87EwMr9Q,"
	 		+ "UCKKnSKTzn7ajPdEGt65EZGQ,"
	 		+ "UCKL6uS0NywFgS2eg4jyOrAA,"
	 		+ "UCKNdfTZCJuOQfWN5Pe5UAAQ,"
	 		+ "UCKU8-0_j7rgZRO-_xZ1TExQ,"
	 		+ "UCKUMvfnMBsZBOe8h7ze_hiw,"
	 		+ "UCKW51b7h8y-eSP4FuwTy01g,"
	 		+ "UCKYR8hgWqIY_Qx8wobn5NdA,"
	 		+ "UCKam8D4Mv5M-fKFnTU5puDQ,"
	 		+ "UCKby5Cq9jArperhkdbX1X6g,"
	 		+ "UCKcXypG00FkZfI_4FIcN1kA,"
	 		+ "UCKd2rI7xVJm86kav7okWC6A,"
	 		+ "UCKgeysSmGKSNIpM0PDFJxsg,"
	 		+ "UCKij1eDeREBfh_LW0hEaIkg,"
	 		+ "UCKitX3MzbFuVJHoRiYQwEpw,"
	 		+ "UCKko_j0VVyswrIOATBhmZZQ,"
	 		+ "UCKkxVSUMRvmvAXMNzjI03Ag,"
	 		+ "UCKltDftlLCnvMCKJYBQ7o_A,"
	 		+ "UCKnPSYx4KiQ1V4wopo9H7eQ,"
	 		+ "UCKosXl2T0fW0CfULV61lnDQ,"
	 		+ "UCLJs55bZWMsCBPekt3vssoQ,"
	 		+ "UCLKuglhGlMmDteQKoniENIQ,"
	 		+ "UCLLGccON9y08RB7xqusu_Ww,"
	 		+ "UCLLo3MaJYSuyP5xLgM5Zr2w,"
	 		+ "UCLLsy41eyYj9r65-8g5CkyA,"
	 		+ "UCLMnOm8WnhK4kUEX_xP0khA";
	 String getURL = url + 
			 "&id=" + id + "&key=" + key;
	 String json = readJsonFromUrl(getURL);
	 ArrayList<String> vo = new ArrayList<String>();
     
	 JSONParser jsonParser = new JSONParser();
       
	 //JSON�����͸� �־� JSON Object �� ����� �ش�.
       JSONObject jsonObject = (JSONObject) jsonParser.parse(json);
       
       //books�� �迭�� ����
       JSONArray bookInfoArray = (JSONArray) jsonObject.get("items");
       for(int i=0; i<bookInfoArray.size(); i++){
           //�迭 �ȿ� �ִ°͵� JSON���� �̱� ������ JSON Object �� ����
           JSONObject bookObject1 = (JSONObject) bookInfoArray.get(i);
           bookObject1 = (JSONObject) bookObject1.get("statistics");
           vo.add(bookObject1.get("viewCount").toString());
           vo.add(bookObject1.get("subscriberCount").toString());
           vo.add(bookObject1.get("videoCount").toString());
           JSONObject bookObject2 = (JSONObject) bookInfoArray.get(i);
           vo.add(bookObject2.get("id").toString());
           
           
           //JSON name���� ����
           System.out.println("ä�� ���� >");             
           System.out.println("�� ��ȸ�� > "+bookObject1.get("viewCount"));
           System.out.println("������ �� > "+bookObject1.get("subscriberCount"));
           System.out.println("�� ����� > "+bookObject1.get("videoCount"));
           System.out.println("CID > "+bookObject2.get("id"));
           System.out.println();
       }
       System.out.println(vo);
 }
 
}