function email_check( email ) {
    
    var regex=/^[a-zA-Z0-9.!#$%&amp;'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
    return (email != '' && email != 'undefined' && regex.test(email));

}


$(document).ready(function() {
   
   $('#user_id').blur(function(){
      var user_id = $('#user_id').val();
      console.log("aa");
      $.ajax({
         url : './idCheck.do?user_id=' + user_id,
         type : 'GET',
         success : function(data) {
            console.log("1 = o / 0 = x : "+ data);                     
            
            if (data == 1) {
                  // 1 : 아이디가 중복되는 문구
                  $('#id_check_text').text('\uC774\uBBF8 \uC874\uC7AC\uD558\uB294 ID\uC785\uB2C8\uB2E4.');
                  $('#id_check_text').css('color', 'red');
                  $('#id_check_img').attr('src','./resources/images/error.png');
                  $("#join_button").attr("disabled", true);
               } else {
                  if(user_id == ""){
                     $('#id_check_text').text('input id :)');
                     $('#id_check_text').css('color', 'red');
                     $('#id_check_img').attr('src','./resources/images/error.png');
                     $("#join_button").attr("disabled", true);            
                  }else if(email_check(user_id)){
                     $('#id_check_text').text('pass');
                     $('#id_check_text').css('color', 'green');
                     $('#id_check_img').attr('src','./resources/images/check.png');
                     $("#join_button").attr("disabled", false);
                  }
         
               }
            }, error : function() {
                  console.log("fail");
            }
         });
      
      
   });
   

});//js end
$(document).ready(function() {
	
	$('#leftarrow').click(function(){
		  var startPage = parseInt(paging.startPage)-1;
		  var cntPerPage = parseInt(paging.cntPerPage);
		  var url = "./boardList.do?nowPage="+ startPage +"&cntPerPage="+ cntPerPage;
		  $.ajax({
				type:'GET',
				url: url,
			    success: function(result) {
			    	 $("#innertable").html(result).trigger("create");
			    }//success end
			});//ajax end
		  
	});//click function end
	
	$('#rightarrow').click(function(){
		  var endPage = parseInt(paging.endPage)+1;
		  var cntPerPage = parseInt(paging.cntPerPage);
		  var url = "./boardList.do?nowPage="+ endPage +"&cntPerPage="+ cntPerPage;
		  $.ajax({
				type:'GET',
				url: url,
			    success: function(result) {
			    	 $("#innertable").html(result).trigger("create");
			    }//success end
			});//ajax end
	});//click function end
	
	
	
	$('a[name="nowpage"]').click(function(){
		  var nowPage = $(this).attr('value');
		  var cntPerPage = parseInt(paging.cntPerPage);
		  //href="./boardList.do?nowPage=${p }&cntPerPage=${paging.cntPerPage}"
		  //alert("nowPage>"+nowPage+" cntPerPage"+cntPerPage);
		  var url = "./boardList.do?nowPage="+ nowPage +"&cntPerPage="+ cntPerPage;
		  $.ajax({
			  type:'GET',
			  url: url,
			  success: function(result) {
				  $("#innertable").html(result).trigger("create");
			  }//success end
		  });//ajax end	
	});
	
	
	$('input[name="commentcount_btn"]').click(function(){
		  var i = $("input[name='commentcount_btn']").index(this);
		  var vid = $("input[name='vid']").eq(i).val();
		  var data = { "vid": vid };
		  console.log("buttonevent");
	$.ajax({
		type:'POST',
		url:'./commentcount.do',
	    data: data,
	    beforeSend:function(){
	    	$('#Progress_Loading').show(); //ajax실행시 로딩바를 보여준다.
	    	$('#Progress_Loading').css('z-index', 3000);
        },
	    success: function(result) {
	    	$('#Progress_Loading').hide(); //ajax종료시 로딩바를 숨겨준다.
	    	 $("#inner").html(result).trigger("create");
	    }//success end
	});//ajax end
	function email_check( email ) {
		   var regex = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
		    //var regex=/^[a-zA-Z0-9.!#$%&amp;'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
		    return (email != '' && email != 'undefined' && regex.test(email));

		}

		$(document).ready(function() {
		   
		   //id check
		   $('#user_id').blur(function(){
		      var user_id = $('#user_id').val();
		      //console.log("aa");
		      $.ajax({
		         url : './idCheck.do?user_id=' + user_id,
		         type : 'GET',
		         success : function(data) {
		            console.log("1 = o / 0 = x : "+ data);                     
		            
		            if (data == 1) {
		                  // 1 : 아이디가 중복되는 문구
		                  $('#id_check_text').text('\uC774\uBBF8 \uC874\uC7AC\uD558\uB294 ID\uC785\uB2C8\uB2E4.');
		                  $('#id_check_text').css('color', 'red');
		                  $('#id_check_img').attr('src','./resources/images/error.png');
		                  $("#join_button").attr("disabled", true);
		               } else {
		                  if(user_id == ""){
		                     $('#id_check_text').text('input id :)');
		                     $('#id_check_text').css('color', 'red');
		                     $('#id_check_img').attr('src','./resources/images/error.png');
		                     $("#join_button").attr("disabled", true);            
		                  }else if(email_check(user_id)){
		                     $('#id_check_text').text('pass');
		                     $('#id_check_text').css('color', 'green');
		                     $('#id_check_img').attr('src','./resources/images/check.png');
		                     $("#join_button").attr("disabled", false);
		                  }
		         
		               }
		            }, error : function() {
		                  console.log("fail");
		            }
		         });
		      
		      
		   });
		   
		   //채널cid check
		   $('.youtube_ch').blur(function(){

		      // alert($('.youtube_ch').val());  
		         var cid = $('.youtube_ch').val();
		         $.ajax({
		            url : './cidCheck.do?cid=' + cid,
		            type : 'GET',
		            success : function(data) {
		               console.log("cid 1 = o / 0 = none : "+ data);                     
		               
		               if (data == 1) {
		                     // 1 : 중복 채널
		                     $('#cid_check_text').text('\uC911\uBCF5\uB418\uB294 \uCC44\uB110ID \uC785\uB2C8\uB2E4.');
		                     $('#cid_check_text').css('color', 'red');
		                     $('#cid_check_img').attr('src','./resources/images/error.png');
		                     $("#join_button").attr("disabled", true);
		                  } else {
		                     if(cid == ""){
		                        $('#cid_check_text').text('input cid :)');
		                        $('#cid_check_text').css('color', 'red');
		                        $('#cid_check_img').attr('src','./resources/images/error.png');
		                        $("#join_button").attr("disabled", true);            
		                     }else{
		                        $('#cid_check_text').text('pass');
		                        $('#cid_check_text').css('color', 'green');
		                        $('#cid_check_img').attr('src','./resources/images/check.png');
		                        $("#join_button").attr("disabled", false);
		                     }
		            
		                  }
		               }, error : function() {
		                     console.log("fail");
		               }
		            });
		         
		         
		      });
		   

		});//js end


	});//click function end

});//js end

