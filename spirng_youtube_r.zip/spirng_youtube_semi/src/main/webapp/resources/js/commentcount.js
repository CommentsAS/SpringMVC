$(document).ready(function() {

     //라디오 요소처럼 동작시킬 체크박스 그룹 셀렉터
    $('input[type="checkbox"][name="positive"]').click(function(){
       //console.log($('input[type="checkbox"][name="positive"]').index(this));
       var idx = $('input[type="checkbox"][name="positive"]').index(this);
        //클릭 이벤트 발생한 요소가 체크 상태인 경우
        if ($(this).prop('checked')) {
            //체크박스 그룹의 요소 전체를 체크 해제후 클릭한 요소 체크 상태지정
           $('input[type="checkbox"][name="positive"]').eq(idx).prop('checked', false);
            $('input[type="checkbox"][name="negative"]').eq(idx).prop('checked', false);
            $(this).prop('checked', true);
        }
    });
   
    $('input[type="checkbox"][name="negative"]').click(function(){
       //console.log($('input[type="checkbox"][name="negative"]').index(this));
       var idx = $('input[type="checkbox"][name="negative"]').index(this);
        //클릭 이벤트 발생한 요소가 체크 상태인 경우
        if ($(this).prop('checked')) {
            //체크박스 그룹의 요소 전체를 체크 해제후 클릭한 요소 체크 상태지정
           $('input[type="checkbox"][name="positive"]').eq(idx).prop('checked', false);
            $('input[type="checkbox"][name="negative"]').eq(idx).prop('checked', false);
            $(this).prop('checked', true);
        }
    });
   
   $('#clear_check').click(function(){
      $("input[type=checkbox]").prop("checked",false);
   });
   
    
   $('#save_dic').click(function(){
      var items=[]; var positive=[]; var negative=[]; var score=[];
      $('.type07 tbody tr th .neutral').each(function(i,e){
         items.push($(this).text());
         positive.push($(this).parent().parent().children('td:nth-child(3)').children('.positive').prop('checked'));
         negative.push($(this).parent().parent().children('td:nth-child(4)').children('.negative').prop('checked'));
      });
      //console.log(positive)
      //console.log(negative)
   
      for(let i=0; i<items.length; i++){
         if(positive[i] == negative[i]) score[i]= 0;
         else {
            if(positive[i] == true) score[i] = 1;
            else score[i] = -1;
         }
      }

      //console.log(score);
      var data = { "items": items, "score":score };
   
      $.ajax({
         type:'POST',
         url:'./adddic.do', //controller adddic 만들기
         data:data,
         success: function(result) {
            $("input[type=checkbox]").prop("checked",false);
            alert("complete");
         }//success end


      });//ajax end
   
   });//click function end

});//js end