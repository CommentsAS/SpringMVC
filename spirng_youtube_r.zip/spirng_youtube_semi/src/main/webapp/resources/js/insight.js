$(document).ready(function() {
	alert("aaaa")
	$.ajax({
		type:'GET',
		url:'./boardList.do',
	    error:function(request, status, error){
	        alert("code:"+request.status+ "\n"+"message:"+request.responseText+"\n"+"error:"+error);
	    },
	    success: function(result) {
	    	 $("#innertable").html(result).trigger("create");
	    }//success end
	});//ajax end
	
	$('#Progress_Loading').hide(); //첫 시작시 로딩바를 숨겨준다.
	
	$('input[name="commentcount_btn"]').click(function(){
		  var i = $("input[name='commentcount_btn']").index(this);
		  var vid = $("input[name='vid']").eq(i).val();
		  var data = { "vid": vid };
		  console.log("buttonevent");
	$.ajax({
		type:'POST',
		url:'./commentcount.do',
	    data: data,
	    success: function(result) {
	    	 $("#inner").html(result).trigger("create");
	    }//success end
	});//ajax end
	
	});//click function end

}).ajaxStart(function(){
	$('#Progress_Loading').show(); //ajax실행시 로딩바를 보여준다.
	$('#Progress_Loading').css('z-index', 3000);
})
.ajaxStop(function(){
	$('#Progress_Loading').hide(); //ajax종료시 로딩바를 숨겨준다.
});//js end
  
  //ready function end