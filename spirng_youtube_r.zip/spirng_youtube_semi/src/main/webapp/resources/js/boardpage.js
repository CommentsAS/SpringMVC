$(document).ready(function() {
	
	$('#leftarrow').click(function(){
		  var startPage = parseInt(paging.startPage)-1;
		  var cntPerPage = parseInt(paging.cntPerPage);
		  var url = "./boardList.do?nowPage="+ startPage +"&cntPerPage="+ cntPerPage;
		  $.ajax({
				type:'GET',
				url: url,
			    success: function(result) {
			    	 $("#innertable").html(result).trigger("create");
			    }//success end
			});//ajax end
		  
	});//click function end
	
	$('#rightarrow').click(function(){
		  var endPage = parseInt(paging.endPage)+1;
		  var cntPerPage = parseInt(paging.cntPerPage);
		  var url = "./boardList.do?nowPage="+ endPage +"&cntPerPage="+ cntPerPage;
		  $.ajax({
				type:'GET',
				url: url,
			    success: function(result) {
			    	 $("#innertable").html(result).trigger("create");
			    }//success end
			});//ajax end
	});//click function end
	
	
	
	$('a[name="nowpage"]').click(function(){
		  var nowPage = $(this).attr('value');
		  var cntPerPage = parseInt(paging.cntPerPage);
		  //href="./boardList.do?nowPage=${p }&cntPerPage=${paging.cntPerPage}"
		  //alert("nowPage>"+nowPage+" cntPerPage"+cntPerPage);
		  var url = "./boardList.do?nowPage="+ nowPage +"&cntPerPage="+ cntPerPage;
		  $.ajax({
			  type:'GET',
			  url: url,
			  success: function(result) {
				  $("#innertable").html(result).trigger("create");
			  }//success end
		  });//ajax end	
	});
	
	
	$('input[name="commentcount_btn"]').click(function(){
		  var i = $("input[name='commentcount_btn']").index(this);
		  var vid = $("input[name='vid']").eq(i).val();
		  var data = { "vid": vid };
		  console.log("buttonevent");
	$.ajax({
		type:'POST',
		url:'./commentcount.do',
	    data: data,
	    beforeSend:function(){
	    	$('#Progress_Loading').show(); //ajax실행시 로딩바를 보여준다.
	    	$('#Progress_Loading').css('z-index', 3000);
        },
	    success: function(result) {
	    	$('#Progress_Loading').hide(); //ajax종료시 로딩바를 숨겨준다.
	    	 $("#inner").html(result).trigger("create");
	    }//success end
	});//ajax end
	
	});//click function end

});//js end

